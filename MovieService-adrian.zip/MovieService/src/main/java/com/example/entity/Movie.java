package com.example.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="movie")
public class Movie {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mov_id;
	
	@Column(nullable=false)
	private String mov_title;

	@Column(nullable=false)
	private String mov_description;

	@Column(nullable=false)
	private int mov_relyear; 

	@Column(nullable=false)
	private String mov_language; 

	@Column(nullable=false)
	private int mov_runtime;

	@Column(nullable=false)
	private String mov_director;

	@Column(nullable=false)
	private String mov_actor;

	@Column(nullable=false)
	private double mov_rating;

	@Column(nullable=false)
	private int mov_genre_id;

}
