package com.example.services;

import java.util.List;

import com.example.entity.Movie;

public interface MovieService {
	public Movie getMovieBasedOnId(int id);
	public List<Movie> GetAllMovies();
	public Movie addMovie(Movie movie);
	public Movie updateMovie(Movie movie);
	public void deleteMovie(Movie movie);
}
