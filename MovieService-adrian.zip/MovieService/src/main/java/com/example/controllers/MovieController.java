package com.example.controllers;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.entity.Movie;
import com.example.responses.MovieResponse;
import com.example.services.MovieService;


@RestController
@RequestMapping("/movies/")
public class MovieController {
	@Autowired
	private RestTemplate restobj;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private MovieService serv;
	
//	@Value("${genreservice.base.url}")
//	private String BaseURL;
//	
//	@Autowired
//	private DiscoveryClient dclient;
//	
//	@Autowired
//	private LoadBalancerClient loadbal;
	
	@GetMapping("/{id}")
	public ResponseEntity<MovieResponse> GetById(@PathVariable int id)
	{
//		ServiceInstance service= loadbal.choose("GENRE-API");
//		String uri=service.getUri().toString();
//		String FinalUri=uri+"/genre-app/api/genre/"+id;
		
		Movie mov=serv.getMovieBasedOnId(id);
		MovieResponse resp=modelMapper.map(mov, MovieResponse.class);
//		GenreResponse genre= restobj.getForObject(FinalUri, GenreResponse.class);
//		resp.setGenre(genre);
		
		return ResponseEntity.status(HttpStatus.OK).body(resp);
	}
	
	@GetMapping("/")
	public ResponseEntity<List<Movie>> GetAll()
	{
		List<Movie> movies=serv.GetAllMovies();
		return ResponseEntity.status(HttpStatus.OK).body(movies);
	}
	
	@PostMapping("/add")
	public ResponseEntity<Movie> Add(@RequestBody Movie mov)
	{
		Movie movie=serv.addMovie(mov);
		return ResponseEntity.status(HttpStatus.CREATED).body(movie);
	}
	
	@PutMapping("/edit")
	public ResponseEntity<Movie> Update(@RequestBody Movie mov)
	{
		Movie movie=serv.updateMovie(mov);
		return ResponseEntity.ok(movie);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> Delete(@PathVariable int id)
	{
		serv.deleteMovie(serv.getMovieBasedOnId(id));
		return ResponseEntity.ok("Deleted Successfully!");
	}
}
